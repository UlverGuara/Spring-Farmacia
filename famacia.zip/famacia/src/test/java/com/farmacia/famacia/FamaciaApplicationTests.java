package com.farmacia.famacia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FamaciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
