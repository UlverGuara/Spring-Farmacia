package com.farmacia.famacia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FamaciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FamaciaApplication.class, args);
	}

}
